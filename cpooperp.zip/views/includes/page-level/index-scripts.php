<!-- Page level plugins -->
<script src="<?= BASEASSETS;?>vendor/chart.js/Chart.min.js"></script>

<!-- Page level custom scripts -->
<script src="<?= BASEASSETS;?>js/demo/chart-area-demo.js"></script>
<script src="<?= BASEASSETS;?>js/demo/chart-pie-demo.js"></script>