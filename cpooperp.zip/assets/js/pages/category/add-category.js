$(function(){
    $('#add-category').vaidate({
        rules: {
            'name':{
                required: true
            }
        },
        submitHandler: function (form){
            form.submit();
        }
    })
});