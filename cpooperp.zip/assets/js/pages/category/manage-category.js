var TableDatatables = function(){
    var handleCategoryTable = function(){
        var manageCategoryTable = $("#manage-category-table");
        var baseURL = window.location.origin;
        var filepath = "/helper/routing.php";//yaha slash daalna padh rh hai bcoz base url se nhi aa rha 
        manageCategoryTable.dataTable({
            "processing": true,
            "serverSide": true,
            "ajax": {
                url: baseURL+filepath,
                type: "POST",
                data:
                {
                    "page": "manage_category"
                }
            }
        })
    }
    return {
        //main function to handle all the datatables
        init: function() {
            handleCategoryTable();
        } 
    }
}();

jQuery(document).ready(function(){
    TableDatatables.init();
});