<?php
define('BASEURL', $di->get('config')->get('base_url'));
define('BASEASSETS', BASEURL."assets/");
define('BASEPAGES', BASEURL."views/pages/");

define("ADD_SUCCESS","add_success");
define("ADD_ERROR","add_error");
define("VALIDATION_ERROR","validation_error");
